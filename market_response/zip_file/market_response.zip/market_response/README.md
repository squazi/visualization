dynamci composition I ... equity dynamic response to fluctuating trading volume
